/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

/* Freescale includes. */
#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "board.h"

#include "pin_mux.h"
#include "clock_config.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* Task priorities. */
#define hello_task_PRIORITY (configMAX_PRIORITIES - 1)
#define servo_task_PRIORITY (configMAX_PRIORITIES - 1)
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static void keepalive_task(void *pvParameters);
extern void servo_task(void *pvParameters);

extern void ftm_init(void);
extern void BOARD_InitGPIOInterrupts (void);
/*******************************************************************************
 * Code
 ******************************************************************************/
extern volatile bool g_ButtonPress;

#define MAX_CMD_LENGTH 2
QueueHandle_t servo_queue = NULL;

/*!
 * @brief Application entry point.
 */
int main(void)
{

    /* Init board hardware. */
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    BOARD_InitGPIOInterrupts(); //Initialize all the GPIO for PTA4 and PTC6 for interrupt pins

    //RTOS objects needed to be started before the scheduler:
    servo_queue = xQueueCreate(10, MAX_CMD_LENGTH);
	/* Enable queue view in MCUX IDE FreeRTOS TAD plugin. */
	if (servo_queue != NULL)
	{
		vQueueAddToRegistry(servo_queue, "servo");
	}

    //RTOS tasks needed to be started before the scheduler:
    if (xTaskCreate(keepalive_task, "KeepAlive_task", configMINIMAL_STACK_SIZE + 10, NULL, hello_task_PRIORITY, NULL) != pdPASS)
    {
        PRINTF("Task creation failed!.\r\n");
        while (1)
            ;
    }
    if (xTaskCreate(servo_task, "servo_task", configMINIMAL_STACK_SIZE + 10, NULL, servo_task_PRIORITY, NULL) != pdPASS)
    {
        PRINTF("Task creation failed!.\r\n");
        while (1)
            ;
    }

    //Start the RTOS scheduler:
    vTaskStartScheduler();
    for (;;)
        ;
}

/*!
 * @brief Task responsible for providing a keepalive signal.
 */
static void keepalive_task(void *pvParameters)
{
	int i=0;

    for (;;)
    {
		if (g_ButtonPress)
		{
			/* Reset state of button. */
			g_ButtonPress = false;

			PRINTF("Detected a Push Button Pressed.\r\n");
		}
        vTaskDelay(100);
		PRINTF("KeepAlive: %d.\r\n", i++);
    }
}


