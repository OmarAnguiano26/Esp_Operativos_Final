/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

/* Freescale includes. */
#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "board.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "nfc_task.h"

#include "SEGGER_SYSVIEW.h"
/* Include internal header to get SEGGER_RTT_CB */
#include "SEGGER_RTT.h"

#define SYSVIEW_DEVICE_NAME "FRDMK64F Cortex-M4"
#define SYSVIEW_RAM_BASE (0x1FFF0000)

extern SEGGER_RTT_CB _SEGGER_RTT;
extern const SEGGER_SYSVIEW_OS_API SYSVIEW_X_OS_TraceAPI;

/* The application name to be displayed in SystemViewer */
#ifndef SYSVIEW_APP_NAME
#define SYSVIEW_APP_NAME "SDK System view example"
#endif

/* The target device name */
#ifndef SYSVIEW_DEVICE_NAME
#define SYSVIEW_DEVICE_NAME "Generic Cortex device"
#endif

/* Frequency of the timestamp. Must match SEGGER_SYSVIEW_GET_TIMESTAMP in SEGGER_SYSVIEW_Conf.h */
#define SYSVIEW_TIMESTAMP_FREQ (configCPU_CLOCK_HZ)

/* System Frequency. SystemcoreClock is used in most CMSIS compatible projects. */
#define SYSVIEW_CPU_FREQ configCPU_CLOCK_HZ

/* The lowest RAM address used for IDs (pointers) */
#ifndef SYSVIEW_RAM_BASE
#define SYSVIEW_RAM_BASE 0x20000000
#endif

/*!
 * @brief System View callback
 */
static void _cbSendSystemDesc(void)
{
    SEGGER_SYSVIEW_SendSysDesc("N=" SYSVIEW_APP_NAME ",D=" SYSVIEW_DEVICE_NAME ",O=FreeRTOS");
    SEGGER_SYSVIEW_SendSysDesc("I#15=SysTick");
}

/*!
 * @brief System View configuration
 */
void SEGGER_SYSVIEW_Conf(void)
{
    SEGGER_SYSVIEW_Init(SYSVIEW_TIMESTAMP_FREQ, SYSVIEW_CPU_FREQ, &SYSVIEW_X_OS_TraceAPI, _cbSendSystemDesc);
    SEGGER_SYSVIEW_SetRAMBase(SYSVIEW_RAM_BASE);
}
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* Task priorities. */
#define keepalive_task_PRIORITY (configMAX_PRIORITIES - 4)
#define servo_task_PRIORITY (configMAX_PRIORITIES - 3)
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static void keepalive_task(void *pvParameters);
extern void servo_task(void *pvParameters);

extern void ftm_init(void);
extern void BOARD_InitGPIOInterrupts (void);

#define TASK_NFC_STACK_SIZE		1024
#define TASK_NFC_STACK_PRIO		(configMAX_PRIORITIES - 1)
/*******************************************************************************
 * Code
 ******************************************************************************/
extern volatile bool g_ButtonPress;

#define MAX_CMD_LENGTH 2
QueueHandle_t servo_queue = NULL;

/*!
 * @brief Application entry point.
 */
int main(void)
{

    /* Init board hardware. */
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    BOARD_InitGPIOInterrupts(); //Initialize all the GPIO for PTA4 and PTC6 for interrupt pins

    SEGGER_SYSVIEW_Conf();

    //RTOS objects needed to be started before the scheduler:
    servo_queue = xQueueCreate(10, MAX_CMD_LENGTH);
	/* Enable queue view in MCUX IDE FreeRTOS TAD plugin. */
	if (servo_queue != NULL)
	{
		vQueueAddToRegistry(servo_queue, "servo");
	}

    //RTOS tasks needed to be started before the scheduler:
    if (xTaskCreate(keepalive_task, "KeepAlive_task", configMINIMAL_STACK_SIZE + 10, NULL, keepalive_task_PRIORITY, NULL) != pdPASS)
    {
        PRINTF("Task creation failed!.\r\n");
        while (1)
            ;
    }
    if (xTaskCreate(servo_task, "servo_task", configMINIMAL_STACK_SIZE + 10, NULL, servo_task_PRIORITY, NULL) != pdPASS)
    {
        PRINTF("Task creation failed!.\r\n");
        while (1)
            ;
    }

	PRINTF("\n\rRunning the NXP-NCI task.\n\r");

	/* Create NFC task */
    if (xTaskCreate((TaskFunction_t) task_nfc,
    				(const char*) "NFC_task",
					TASK_NFC_STACK_SIZE,
					NULL,
					TASK_NFC_STACK_PRIO,
					NULL) != pdPASS)
    {
    	PRINTF("Failed to create NFC task");
    }

    //Start the RTOS scheduler:
    vTaskStartScheduler();
    for (;;)
        ;
}

/*!
 * @brief Task responsible for providing a keepalive signal.
 */
static void keepalive_task(void *pvParameters)
{
	int i=0;

	PRINTF("RTT block address is: 0x%x \r\n", &_SEGGER_RTT);

    for (;;)
    {
		if (g_ButtonPress)
		{
			/* Reset state of button. */
			g_ButtonPress = false;

			PRINTF("Detected a Push Button Pressed.\r\n");
		}
        vTaskDelay(100);
		PRINTF("KeepAlive: %d.\r\n", i++);
    }
}

U32 SEGGER_SYSVIEW_X_GetTimestamp(void)
{
    return __get_IPSR() ? xTaskGetTickCountFromISR() : xTaskGetTickCount();
}
